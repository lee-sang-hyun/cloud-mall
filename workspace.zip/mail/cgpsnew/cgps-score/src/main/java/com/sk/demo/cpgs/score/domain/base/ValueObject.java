package com.sk.demo.cpgs.score.domain.base;

public interface ValueObject {
}
