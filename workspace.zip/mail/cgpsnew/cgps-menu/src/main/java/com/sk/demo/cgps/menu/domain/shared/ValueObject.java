package com.sk.demo.cgps.menu.domain.shared;

public interface ValueObject {
}
