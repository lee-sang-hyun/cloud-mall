package com.sk.demo.domain.base;

public interface AggregateRoot {
}
