package com.sk.demo.cpgs.reservation.domain.base;

public interface ValueObject {
}
