package com.sk.sample.mall.account.domain.model;

public enum MembershipLevelType {
	VIP,
	GOLD,
	SILVER
}
