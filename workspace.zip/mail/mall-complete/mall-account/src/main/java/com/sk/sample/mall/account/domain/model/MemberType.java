package com.sk.sample.mall.account.domain.model;

public enum MemberType {
	SELLER,
	BUYER
}
