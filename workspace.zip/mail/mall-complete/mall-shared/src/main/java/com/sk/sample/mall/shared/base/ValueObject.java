package com.sk.sample.mall.shared.base;

public interface ValueObject {
}
