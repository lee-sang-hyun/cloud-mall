package com.sk.sample.mall.payment.domain.service;

import com.sk.sample.mall.payment.domain.model.Payment;

public interface PaymentService {
	Payment pay(Payment payment);
}
