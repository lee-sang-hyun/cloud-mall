package com.sk.sample.mall.order.application.proxy.feign.dto.account;

public enum MemberType {
	SELLER,
	BUYER
}
