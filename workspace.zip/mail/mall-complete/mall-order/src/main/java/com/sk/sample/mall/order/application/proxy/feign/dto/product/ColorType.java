package com.sk.sample.mall.order.application.proxy.feign.dto.product;

public enum ColorType {
	RED, ORANGE, YELLOW, GREEN, BLUE, NAVY, PURPLE
}

