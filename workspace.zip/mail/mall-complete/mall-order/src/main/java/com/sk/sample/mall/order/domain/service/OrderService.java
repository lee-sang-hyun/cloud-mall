package com.sk.sample.mall.order.domain.service;

public interface OrderService {
	void purchase(Long orderId);
}
