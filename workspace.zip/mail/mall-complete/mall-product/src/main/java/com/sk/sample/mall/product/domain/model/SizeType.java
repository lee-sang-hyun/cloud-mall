package com.sk.sample.mall.product.domain.model;

public enum SizeType {
	S, M, L, XL
}

