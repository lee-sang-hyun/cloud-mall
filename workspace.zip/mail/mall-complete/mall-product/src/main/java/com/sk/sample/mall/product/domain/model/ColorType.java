package com.sk.sample.mall.product.domain.model;

public enum ColorType {
	RED, ORANGE, YELLOW, GREEN, BLUE, NAVY, PURPLE
}

